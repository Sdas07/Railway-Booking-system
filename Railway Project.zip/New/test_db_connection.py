from helpers.config import get_db

try:
    db = get_db()
    print("Successfully connected to MongoDB!")
except Exception as e:
    print(f"Connection failed: {e}")
