from bson import ObjectId
from helpers.config import get_db

def get_all_trains():
    """
    Fetch all trains from the database.
    """
    db = get_db()
    return list(db['trains'].find())

def get_train_by_id(train_id):
    """
    Fetch a single train by ID.
    """
    db = get_db()
    return db['trains'].find_one({'_id': ObjectId(train_id)})

def update_train_seats(train_id, seats_to_book):
    """
    Update the seat count for a train.
    """
    db = get_db()
    db['trains'].update_one(
        {'_id': ObjectId(train_id)},
        {'$inc': {'seats': -seats_to_book}}
    )
