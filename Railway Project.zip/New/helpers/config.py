from dotenv import load_dotenv
import os
from pymongo import MongoClient

# Load environment variables from .env file
load_dotenv()

def get_db():
    """
    Connect to MongoDB and return the database object.
    """
    try:
        # Get Mongo URI from environment variable (default to localhost if not set)
        mongo_uri = os.getenv('MONGO_URI', 'mongodb://localhost:27017/')
        client = MongoClient(mongo_uri)
        
        # Get the database named 'railway_db'
        db = client['railway_db']
        return db
    except Exception as e:
        raise Exception(f"Error connecting to MongoDB: {str(e)}")
