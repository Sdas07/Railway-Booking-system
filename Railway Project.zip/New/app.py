from flask import Flask, render_template, request, redirect, url_for, session, jsonify
from bson import ObjectId
from helpers.config import get_db

app = Flask(__name__)
app.secret_key = 'your_secret_key'  # To keep user sessions secure

@app.route('/')
def landing_page():
    """
    Landing page displaying the login form.
    """
    return render_template('login.html')

@app.route('/user_home')
def user_dashboard():
    """
    Dashboard for logged-in users to view available trains.
    """
    if 'user_id' not in session or session.get('role') != 'user':
        return redirect(url_for('landing_page'))  # Redirect to login if not logged in as user
    try:
        db = get_db()
        trains = list(db['trains'].find())  # Fetch all trains from the database
        return render_template('user_home.html', trains=trains)
    except Exception as e:
        return jsonify({"error": str(e)}), 500

@app.route('/admin_dashboard')
def admin_dashboard():
    """
    Dashboard for admins to manage trains, users, and bookings.
    """
    if 'user_id' not in session or session.get('role') != 'admin':
        return redirect(url_for('landing_page'))  # Redirect to login if not logged in as admin
    return render_template('admin_dashboard.html')

@app.route('/book_ticket', methods=['POST'])
def book_ticket():
    """
    Allows users to book tickets for trains.
    """
    if 'user_id' not in session or session.get('role') != 'user':
        return redirect(url_for('landing_page'))  # Redirect if not logged in as user
    try:
        train_id = request.form.get('train_id')
        seats_to_book = request.form.get('seats_to_book')

        if not train_id or not seats_to_book:
            return render_template('error.html', message="Train ID and seats to book are required.")

        seats_to_book = int(seats_to_book)
        if seats_to_book <= 0:
            return render_template('error.html', message="Number of seats must be greater than zero.")

        db = get_db()
        train = db['trains'].find_one({'_id': ObjectId(train_id)})

        if not train:
            return render_template('error.html', message="Train not found.")

        available_seats = train.get('seats', 0)
        if seats_to_book > available_seats:
            return render_template('error.html', message=f"Not enough seats available. Only {available_seats} left.")

        db['trains'].update_one(
            {'_id': ObjectId(train_id)},
            {'$inc': {'seats': -seats_to_book}}
        )

        return render_template(
            'booking_success.html',
            train=train,
            booked_seats=seats_to_book,
            remaining_seats=available_seats - seats_to_book
        )
    except ValueError:
        return render_template('error.html', message="Invalid number of seats entered.")
    except Exception as e:
        return render_template('error.html', message=f"An error occurred: {str(e)}"), 500

@app.route('/login', methods=['POST'])
def login():
    """
    Handles login form submission for both users and admins.
    """
    username = request.form.get('username')
    password = request.form.get('password')

    db = get_db()
    user = db['users'].find_one({'username': username})

    if user and user['password'] == password:
        session['user_id'] = str(user['_id'])
        session['role'] = user['role']  # Store role in session
        
        if user['role'] == 'admin':
            return redirect(url_for('admin_dashboard'))
        else:
            return redirect(url_for('user_dashboard'))
    
    return render_template('error.html', message="Invalid username or password.")

@app.route('/register', methods=['GET', 'POST'])
def register():
    """
    Displays and handles registration form submission.
    """
    if request.method == 'POST':
        username = request.form.get('username')
        password = request.form.get('password')
        confirm_password = request.form.get('confirm_password')
        role = request.form.get('role')  # 'user' or 'admin'

        if password != confirm_password:
            return render_template('error.html', message="Passwords do not match.")

        db = get_db()
        if db['users'].find_one({'username': username}):
            return render_template('error.html', message="Username already exists.")

        db['users'].insert_one({'username': username, 'password': password, 'role': role})
        return redirect(url_for('landing_page'))  # Redirect to login page after registration

    return render_template('register.html')  # Render registration form for GET requests

@app.route('/logout')
def logout():
    """
    Clears session data and logs out the user or admin.
    """
    session.clear()
    return redirect(url_for('landing_page'))

if __name__ == '__main__':
    app.run(debug=True)
